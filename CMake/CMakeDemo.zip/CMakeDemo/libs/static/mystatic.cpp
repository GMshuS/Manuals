#include "mystatic.h"
#include <iostream>

StaticLib::StaticLib() {
    std::cout << "StaticLib created" << std::endl;
}

void StaticLib::print_message() {
    #ifdef DEBUG
    std::cout << "[DEBUG] Message from static library: " << value << std::endl;
    #else
    std::cout << "Message from static library: " << value << std::endl;
    #endif
}

int StaticLib::get_value() const {
    return value;
}