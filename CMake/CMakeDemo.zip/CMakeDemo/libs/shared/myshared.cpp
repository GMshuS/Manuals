#include "myshared.h"
#include <iostream>

int SharedLib::instance_count = 0;

SharedLib::SharedLib() {
    id = ++instance_count;
    std::cout << "SharedLib instance " << id << " created" << std::endl;
}

SharedLib::~SharedLib() {
    std::cout << "SharedLib instance " << id << " destroyed" << std::endl;
    instance_count--;
}

void SharedLib::show() {
    std::cout << "SharedLib instance " << id << " showing" << std::endl;
}

int SharedLib::calculate(int x, int y) {
    return x * y + id;
}

int SharedLib::get_count() {
    return instance_count;
}

// C接口实现
extern "C" {
    SHARED_API int multiply_numbers(int a, int b) {
        return a * b;
    }
    
    SHARED_API const char* get_version() {
        return "1.0.0";
    }
}