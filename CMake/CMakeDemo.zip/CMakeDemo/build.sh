#!/bin/bash

# 创建构建目录
mkdir -p build
cd build

# 配置项目
cmake .. -DCMAKE_BUILD_TYPE=Debug -DENABLE_FEATURE_X=ON

# 编译
cmake --build . --parallel 4

# 运行程序
./bin/CMakeDemo

# 运行测试
ctest --output-on-failure

# 安装
cmake --install . --prefix ../install

# 创建包
cpack -G TGZ