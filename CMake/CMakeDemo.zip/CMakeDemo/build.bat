@echo off

REM 创建构建目录
if not exist build mkdir build
cd build

REM 配置项目
cmake .. -G "Visual Studio 17 2022" -A x64 -DENABLE_FEATURE_X=ON

REM 编译
cmake --build . --config Debug --parallel 4

REM 运行程序
rem .\bin\Debug\CMakeDemo.exe

REM 运行测试
rem ctest --output-on-failure -C Debug

REM 安装
rem cmake --install . --config Debug --prefix ../install