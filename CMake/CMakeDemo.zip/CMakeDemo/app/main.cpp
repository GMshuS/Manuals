#include <iostream>
#include "hello.h"
#include "calc.h"
#include "mystatic.h"
#include "myshared.h"

int main() {
    std::cout << "=== CMake Demo Program ===" << std::endl;
    
    // 1. 使用主源代码模块
    Hello hello;
    hello.sayHello();
    hello.sayHello("CMake User");
    
    Calculator calc;
    std::cout << "Calculation examples:" << std::endl;
    std::cout << "10 + 5 = " << calc.add(10, 5) << std::endl;
    std::cout << "10 - 5 = " << calc.subtract(10, 5) << std::endl;
    std::cout << "10 * 5 = " << calc.multiply(10, 5) << std::endl;
    
    try {
        std::cout << "10 / 5 = " << calc.divide(10, 5) << std::endl;
    } catch (const std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl;
    }
    
    // 2. 使用静态库
    StaticLib staticLib;
    staticLib.print_message();
    std::cout << "Static library value: " << staticLib.get_value() << std::endl;
    
    // 3. 使用动态库
    SharedLib sharedLib1;
    SharedLib sharedLib2;
    
    std::cout << "Shared library instances: " << SharedLib::get_count() << std::endl;
    
    sharedLib1.show();
    sharedLib2.show();
    
    std::cout << "SharedLib calculation: " << sharedLib1.calculate(3, 4) << std::endl;
    std::cout << "SharedLib calculation: " << sharedLib2.calculate(3, 4) << std::endl;
    
    // 使用C接口
    std::cout << "C interface: 6 * 7 = " << multiply_numbers(6, 7) << std::endl;
    std::cout << "Version: " << get_version() << std::endl;
    
    // 4. 条件编译功能
    #ifdef ENABLE_FEATURE_X
    hello.featureX();
    #endif
    
    // 5. 平台特定代码
    #if defined(WIN32)
    hello.windowsSpecific();
    #elif defined(LINUX)
    hello.linuxSpecific();
    #elif defined(MACOSX)
    hello.macSpecific();
    #endif
    
    // 6. 调试信息
    #ifdef DEBUG
    std::cout << "[DEBUG] Program compiled in debug mode" << std::endl;
    #else
    std::cout << "Program compiled in release mode" << std::endl;
    #endif
    
    std::cout << "\n=== Program completed successfully ===" << std::endl;
    return 0;
}