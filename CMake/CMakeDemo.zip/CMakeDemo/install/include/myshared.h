#ifndef MYSHARED_H
#define MYSHARED_H

#ifdef _WIN32
    #ifdef BUILDING_MYSHARED
        #define SHARED_API __declspec(dllexport)
    #else
        #define SHARED_API __declspec(dllimport)
    #endif
#else
    #define SHARED_API
#endif

class SHARED_API SharedLib {
public:
    SharedLib();
    ~SharedLib();
    
    void show();
    int calculate(int x, int y);
    
    static int get_count();
    
private:
    static int instance_count;
    int id = 0;
};

// C接口示例
extern "C" {
    SHARED_API int multiply_numbers(int a, int b);
    SHARED_API const char* get_version();
}

#endif // MYSHARED_H