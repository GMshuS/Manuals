#ifndef MYSTATIC_H
#define MYSTATIC_H

#ifdef _WIN32
    #ifdef BUILDING_MYSTATIC
        #define STATIC_API __declspec(dllexport)
    #else
        #define STATIC_API __declspec(dllimport)
    #endif
#else
    #define STATIC_API
#endif

class STATIC_API StaticLib {
public:
    StaticLib();
    void print_message();
    int get_value() const;
    
private:
    int value = 42;
};

#endif // MYSTATIC_H