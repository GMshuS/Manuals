@echo off
echo ===== 清理项目 =====
echo.

echo 删除旧的构建目录...
if exist build rmdir /s /q build
if exist install rmdir /s /q install

echo.
echo ===== 配置项目 =====
echo.

mkdir build
cd build

REM 配置项目
cmake .. -G "Visual Studio 17 2022" -A x64 ^
  -DCMAKE_BUILD_TYPE=Debug ^
  -DENABLE_FEATURE_X=ON

if %ERRORLEVEL% NEQ 0 (
    echo CMake配置失败！
    exit /b 1
)

echo.
echo ===== 编译项目 =====
echo.

REM 编译项目
cmake --build . --config Debug --parallel 8

if %ERRORLEVEL% NEQ 0 (
    echo 编译失败！
    exit /b 1
)

echo.
echo ===== 运行程序 =====
echo.

cd ..
echo 可执行文件位置: build\bin\debug\cmake_demo.exe
echo.

rem build\bin\debug\cmake_demo.exe