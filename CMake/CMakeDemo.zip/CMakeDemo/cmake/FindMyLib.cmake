# 查找MyLib的CMake模块示例
find_path(MYLIB_INCLUDE_DIR
    NAMES mylib.h
    PATHS
        /usr/include
        /usr/local/include
        ${CMAKE_SOURCE_DIR}/thirdparty/mylib/include
)

find_library(MYLIB_LIBRARY
    NAMES mylib
    PATHS
        /usr/lib
        /usr/local/lib
        ${CMAKE_SOURCE_DIR}/thirdparty/mylib/lib
)

if(MYLIB_INCLUDE_DIR AND MYLIB_LIBRARY)
    set(MYLIB_FOUND TRUE)
    message(STATUS "Found MyLib: ${MYLIB_LIBRARY}")
else()
    set(MYLIB_FOUND FALSE)
    message(WARNING "MyLib not found")
endif()

# 创建导入目标
if(MYLIB_FOUND AND NOT TARGET MyLib::MyLib)
    add_library(MyLib::MyLib UNKNOWN IMPORTED)
    set_target_properties(MyLib::MyLib PROPERTIES
        INTERFACE_INCLUDE_DIRECTORIES "${MYLIB_INCLUDE_DIR}"
        IMPORTED_LOCATION "${MYLIB_LIBRARY}"
    )
endif()