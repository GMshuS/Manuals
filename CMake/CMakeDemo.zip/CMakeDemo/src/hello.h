#ifndef HELLO_H
#define HELLO_H

#include <string>

class Hello {
public:
    void sayHello();
    void sayHello(const std::string& name);
    
    #ifdef ENABLE_FEATURE_X
    void featureX();
    #endif
    
    #if defined(WIN32)
    void windowsSpecific();
    #elif defined(LINUX)
    void linuxSpecific();
    #elif defined(MACOSX)
    void macSpecific();
    #endif
};

#endif // HELLO_H