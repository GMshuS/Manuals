#include "calc.h"
#include <stdexcept>

int Calculator::add(int a, int b) {
    last_result = a + b;
    return last_result;
}

int Calculator::subtract(int a, int b) {
    last_result = a - b;
    return last_result;
}

int Calculator::multiply(int a, int b) {
    last_result = a * b;
    return last_result;
}

double Calculator::divide(int a, int b) {
    if (b == 0) {
        throw std::runtime_error("Division by zero!");
    }
    return static_cast<double>(a) / b;
}