#include "hello.h"
#include <iostream>
#include "calc.h"  // 演示跨文件调用

void Hello::sayHello() {
    #ifdef DEBUG
    std::cout << "[DEBUG] Hello from CMake project!" << std::endl;
    #else
    std::cout << "Hello from CMake project!" << std::endl;
    #endif
    
    // 演示调用其他模块
    Calculator calc;
    std::cout << "5 + 3 = " << calc.add(5, 3) << std::endl;
}

void Hello::sayHello(const std::string& name) {
    std::cout << "Hello, " << name << "!" << std::endl;
}

#ifdef ENABLE_FEATURE_X
void Hello::featureX() {
    std::cout << "Feature X is enabled!" << std::endl;
}
#endif

#if defined(WIN32)
void Hello::windowsSpecific() {
    std::cout << "Running on Windows" << std::endl;
}
#elif defined(LINUX)
void Hello::linuxSpecific() {
    std::cout << "Running on Linux" << std::endl;
}
#elif defined(MACOSX)
void Hello::macSpecific() {
    std::cout << "Running on macOS" << std::endl;
}
#endif