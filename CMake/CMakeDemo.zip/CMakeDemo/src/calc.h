#ifndef CALC_H
#define CALC_H

class Calculator {
public:
    int add(int a, int b);
    int subtract(int a, int b);
    int multiply(int a, int b);
    double divide(int a, int b);
    
private:
    int last_result = 0;
};

#endif // CALC_H