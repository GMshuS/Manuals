#include <iostream>
#include <cassert>
#include "calc.h"

void test_addition() {
    Calculator calc;
    int result = calc.add(2, 3);
    assert(result == 5);
    std::cout << "✓ Addition test passed" << std::endl;
}

void test_subtraction() {
    Calculator calc;
    int result = calc.subtract(10, 4);
    assert(result == 6);
    std::cout << "✓ Subtraction test passed" << std::endl;
}

void test_multiplication() {
    Calculator calc;
    int result = calc.multiply(3, 4);
    assert(result == 12);
    std::cout << "✓ Multiplication test passed" << std::endl;
}

void test_division() {
    Calculator calc;
    double result = calc.divide(10, 2);
    assert(result == 5.0);
    std::cout << "✓ Division test passed" << std::endl;
}

void test_division_by_zero() {
    Calculator calc;
    try {
        calc.divide(10, 0);
        assert(false && "Should have thrown exception");
    } catch (const std::runtime_error& e) {
        assert(std::string(e.what()) == "Division by zero!");
        std::cout << "✓ Division by zero test passed" << std::endl;
    }
}

int main() {
    std::cout << "=== Running Calculator Tests ===" << std::endl;
    
    test_addition();
    test_subtraction();
    test_multiplication();
    test_division();
    test_division_by_zero();
    
    std::cout << "\n=== All tests passed! ===" << std::endl;
    return 0;
}